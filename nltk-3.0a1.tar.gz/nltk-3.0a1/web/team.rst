Team NLTK
=========

:Semantics: `Dan Garrette <http://www.cs.utexas.edu/~dhg/>`, Austin, USA (``nltk.sem, nltk.inference``)
:Parsing: `Peter Ljunglöf <http://www.cse.chalmers.se/~peb/>`, Gothenburg, Sweden (``nltk.parse, nltk.featstruct``)
:Metrics: `Joel Nothman <http://joelnothman.com/>`, Sydney, Australia (``nltk.metrics, nltk.tokenize.punkt``)
:Python 3: `Mikhail Korobov <http://kmike.ru/>`, Ekaterinburg, Russia
:Integration: `Morten Minde Neergaard <http://8d.no/>`, Oslo, Norway
:Releases: `Steven Bird <http://estive.net>`, Melbourne, Australia





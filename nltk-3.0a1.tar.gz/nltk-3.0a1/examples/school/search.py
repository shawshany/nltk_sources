from words import *
words = read_text('corpus/telephone.txt')
concordance(" um", words)



